package dao;

import org.config.HQLConfig;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.models.Meciuri;

import java.util.List;

public class MeciuriDao {

    public void veziMeciuri() {
        try {
            Session session = HQLConfig.getSessionFactory().openSession();
            Query query4 = session.createNamedQuery("get_meci", Meciuri.class);
            List<Meciuri> meciResults = query4.list();
            System.out.println();
            for (Meciuri meciuri : meciResults) {
                System.out.println(meciuri.toString());
            }
            session.close();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        System.out.println();
    }
}
