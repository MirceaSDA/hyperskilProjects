package dao;

import org.config.HQLConfig;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.models.Bilete;
import org.models.Vanzari;

public class VanzariDao {

    public void vanzareBilet(Integer biletId, Integer meciId, int pret) {
        Session session = HQLConfig.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        Vanzari vanzare = new Vanzari();
        vanzare.setTipVanzareId(1);
        vanzare.setBiletId(biletId);
        vanzare.setMeciId(meciId);
        vanzare.setStatus(1);
        vanzare.setAbonamentId(null);
        vanzare.setPret(pret);
        session.save(vanzare);
        tx.commit();
        session.close();
    }

    public void vanzareAbonament(Integer abonamentId, int pret) {
        Session session = HQLConfig.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        Vanzari vanzare = new Vanzari();
        vanzare.setTipVanzareId(2);
        vanzare.setBiletId(null);
        vanzare.setMeciId(null);
        vanzare.setStatus(1);
        vanzare.setAbonamentId(abonamentId);
        vanzare.setPret(pret);
        session.save(vanzare);
        tx.commit();
        session.close();
    }
}
