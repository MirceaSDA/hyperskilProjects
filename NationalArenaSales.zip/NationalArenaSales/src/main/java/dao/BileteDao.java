package dao;

import org.config.HQLConfig;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.models.Bilete;

import javax.persistence.Query;

public class BileteDao {

    public void cumparareBilet(Integer tipLocId, Integer tipCumparatorId, Integer pret, Integer meciId) {
        Session session = HQLConfig.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        Bilete bilet = new Bilete();
        bilet.setTipLocId(tipLocId);
        bilet.setTipCumparatorId(tipCumparatorId);
        bilet.setPret(pret);
        bilet.setMecId(meciId);
        bilet.setStatus(1);
        session.save(bilet);
        tx.commit();
        session.close();
    }

    public void anulareBilet(Integer biletId) {
        Session session = HQLConfig.getSessionFactory().openSession();
        Transaction tx=session.beginTransaction();
        Query anulareBilet = session.createQuery("update Bilete set status =:new where biletId =:biletId");
        anulareBilet.setParameter("new",0);
        anulareBilet.setParameter("biletId",biletId);
        int status = anulareBilet.executeUpdate();
        System.out.println(status);
        tx.commit();
    }

}
