package dao;

import org.config.HQLConfig;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.models.Abonamente;
import org.models.Bilete;

import java.util.Date;

public class AbonamenteDao {

    public void cumparareAbonament(String nume, String prenume, Integer tipLocId, Integer tipCumparatorId,
                                   Integer termenValabilitate, Date dataIncepereValabilitate, Date dataTerminareValabilitate,
                                   Integer pret) {
        Session session = HQLConfig.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        Abonamente abonament = new Abonamente();
        abonament.setNume(nume);
        abonament.setPrenume(prenume);
        abonament.setTipLocId(tipLocId);
        abonament.setTipCumparatorId(tipCumparatorId);
        abonament.setTermenValabilitate(termenValabilitate);
        abonament.setDataIncepereValabilitate(dataIncepereValabilitate);
        abonament.setDataTerminareValabilitate(dataTerminareValabilitate);
        abonament.setPret(pret);
        session.save(abonament);
        tx.commit();
        session.close();
    }

}
