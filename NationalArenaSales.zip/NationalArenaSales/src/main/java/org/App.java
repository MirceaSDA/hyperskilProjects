package org;

import dao.MeciuriDao;
import org.config.HQLConfig;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.models.*;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.utils.MeniuAN;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import static java.time.LocalDate.now;

/**
 * Hello world!
 *
 */

@Configuration
@ComponentScan("java")
public class App {
    public static void main (String[] args) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(App.class);

//        MeniuAN meniuAN = new MeniuAN();
        MeniuAN meniuAN = context.getBean("meniuAN", MeniuAN.class);
//        System.out.println( "Hello World!" );
        System.out.println("JAVA Remote 3 - Proiect Grupa 4: Vanzare de bilete si abonamente " +
                "pe Arena Nationala");

        meniuAN.startProgram();

//        LocalDateTime localdate = LocalDateTime.now() ;
//        System.out.println(localdate);
//        localdate = localdate.plusMonths(12);
//        System.out.println(localdate);

//        Session session = HQLConfig.getSessionFactory().openSession();
//        Transaction tx = session.beginTransaction();
//
//        Bilete bilet = new Bilete();
//        bilet.setTipLocId(4);
//        bilet.setTipCumparatorId(2);
//        bilet.setPret(100);
//
//
//
//        tx.commit();
//
//
//
//
//        Query query = session.createNamedQuery("get_seat_by_name", TipLoc.class);
//        query = query.setParameter("seat_description", "trib%");
//        List<TipLoc> seatsResult = query.list();
//        for (TipLoc seats : seatsResult) {
//            System.out.println(seats.toString());
//        }
//        System.out.println();
//
//        Query query1 = session.createNamedQuery("get_durata_abonament", Abonamente.class);
//        query1 = query1.setParameter("durata_abonament", 12);
//        List<Abonamente> abonamentResult = query1.list();
//        for (Abonamente abonamente : abonamentResult) {
//            System.out.println(abonamente.toString());
//        }
//        System.out.println();
//
//        Query query2 = session.createNamedQuery("get_tip_cumparator", TipCumparator.class);
//        query2 = query2.setParameter("tip_cumparator_description", "adu%");
//        List<TipCumparator> cumparatorResult = query2.list();
//        for (TipCumparator cumparator : cumparatorResult) {
//            System.out.println(cumparator.toString());
//        }
//        System.out.println();
//
//        Query query3 = session.createNamedQuery("get_tip_vanzare", TipVanzare.class);
//        query3 = query3.setParameter("tip_vanzare_description", "abo%");
//        List<TipVanzare> vanzareResult = query3.list();
//        for (TipVanzare tipVanzare : vanzareResult) {
//            System.out.println(tipVanzare.toString());
//        }
//        System.out.println();
//
//
//        System.out.println();
//
//        Query query5 = session.createNamedQuery("get_price", Bilete.class);
//        query5 = query5.setParameter("pret", 100);
//        List<Bilete> bileteResults = query5.list();
//        for (Bilete bilete : bileteResults) {
//            System.out.println(bilete.toString());
//        }
//        System.out.println();
//
//        Query query6 = session.createNamedQuery("get_status", Vanzari.class);
//        query6 = query6.setParameter("status", 1);
//        List<Vanzari> vanzariResults = query6.list();
//        for (Vanzari vanzari1 : vanzariResults) {
//            System.out.println(vanzari.toString());
//        }
//        System.out.println();

    }
}
