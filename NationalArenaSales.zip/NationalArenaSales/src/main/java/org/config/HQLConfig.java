package org.config;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.service.ServiceRegistry;
import org.models.*;

import java.util.Properties;
import java.util.logging.Level;

public class HQLConfig {

    private static SessionFactory sessionFactory;

    public static SessionFactory getSessionFactory() {
        if (sessionFactory == null) {
            try {
                Configuration configuration = new Configuration();
                java.util.logging.Logger.getLogger("org.hibernate").setLevel(Level.OFF);

                //DB CONFIG
                Properties dbSettings = new Properties();
                dbSettings.put(Environment.DRIVER, "com.mysql.cj.jdbc.Driver");
                dbSettings.put(Environment.URL, "jdbc:mysql://localhost:3306/nationalarenasales?serverTimezone=EET");
                dbSettings.put(Environment.USER, "root");
                dbSettings.put(Environment.PASS, "77Claudiu18");
                dbSettings.put(Environment.DIALECT, "org.hibernate.dialect.MySQL5Dialect");
//                dbSettings.put(Environment.SHOW_SQL, "true");
                dbSettings.put(Environment.CURRENT_SESSION_CONTEXT_CLASS, "thread");

                // de aici in jos este partea de MAPPING
                configuration.setProperties(dbSettings);
                configuration.addAnnotatedClass(TipLoc.class);
                configuration.addAnnotatedClass(TipAbonamente.class);
                configuration.addAnnotatedClass(TipCumparator.class);
                configuration.addAnnotatedClass(TipVanzare.class);
                configuration.addAnnotatedClass(Meciuri.class);
                configuration.addAnnotatedClass(Bilete.class);
                configuration.addAnnotatedClass(Vanzari.class);
                configuration.addAnnotatedClass(Abonamente.class);

                ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder()
                        .applySettings(configuration.getProperties()).build();
                sessionFactory = configuration.buildSessionFactory(serviceRegistry);

            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }
        }
        return sessionFactory;
    }
}
