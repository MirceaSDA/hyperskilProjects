package org.models;

import javax.persistence.*;

@NamedQueries({
        @NamedQuery(
                name = "get_tip_vanzare",
                query = "from TipVanzare where tip_vanzare_description like :tip_vanzare_description"
        )
})

@Entity
@Table(name = "tip_vanzare")

public class TipVanzare {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tip_vanzare_id")
    private Integer tipVanzareId;

    @Column (name = "tip_vanzare_description")
    private String tipVanzareDescription;

    public Integer getTipVanzareId() {
        return tipVanzareId;
    }

    public void setTipVanzareId(Integer tipVanzareId) {
        this.tipVanzareId = tipVanzareId;
    }

    public String getTipVanzareDescription() {
        return tipVanzareDescription;
    }

    public void setTipVanzareDescription(String tipVanzareDescription) {
        this.tipVanzareDescription = tipVanzareDescription;
    }

    @Override
    public String toString() {
        return "TipVanzare{" +
                "tipVanzareId=" + tipVanzareId +
                ", tipVanzareDescription=" + tipVanzareDescription +
                '}';
    }
}
