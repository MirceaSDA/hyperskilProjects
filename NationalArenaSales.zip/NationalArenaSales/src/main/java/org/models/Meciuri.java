package org.models;

import javax.persistence.*;
import java.util.Date;
import java.sql.*;

@NamedQueries({
        @NamedQuery(
                name = "get_meci",
                query = "from Meciuri where timestamp(meci_date, meci_time) >= now()"
        )
})

@Entity
@Table(name = "meciuri")

public class Meciuri {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "meci_id")
    private Integer meciId;

    @Column (name = "meci_description")
    private String meciDescription;

    @Column (name = "meci_date")
    private Date meciDate;

    @Column (name = "meci_time")
    private Time meciTime;

    public Integer getMeciId() {
        return meciId;
    }

    public void setMeciId(Integer meciId) {
        this.meciId = meciId;
    }

    public String getMeciDescription() {
        return meciDescription;
    }

    public void setMeciDescription(String meciDescription) {
        this.meciDescription = meciDescription;
    }

    public Date getMeciDate() {
        return meciDate;
    }

    public void setMeciDate(Date meciDate) {
        this.meciDate = meciDate;
    }

    public Time getMeciTime() {
        return meciTime;
    }

    public void setMeciTime(Time meciTime) {
        this.meciTime = meciTime;
    }

    @Override
    public String toString() {
        return "Meciuri{" +
                "meciId=" + meciId +
                ", meciDescription='" + meciDescription + '\'' +
                ", meciDate=" + meciDate +
                ", meciTime=" + meciTime +
                '}';
    }
}
