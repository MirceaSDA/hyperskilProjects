package org.models;

import javax.persistence.*;
import java.util.Date;
import java.sql.*;

@NamedQueries({
        @NamedQuery(
                name = "get_abonament_by_id",
                query = "from Abonamente where abonamentId = :abonamentId"
        )
})

@Entity
@Table(name = "abonamente")

public class Abonamente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "abonament_id")
    private Integer abonamentId;

    @Column (name = "nume")
    private String nume;

    @Column (name = "prenume")
    private String prenume;

    @Column (name = "tip_loc_id")
    private Integer tipLocId;

    @Column (name = "tip_cumparator_id")
    private Integer tipCumparatorId;

    @Column (name = "termen_valabilitate")
    private Integer termenValabilitate;

    @Column (name = "data_incepere_valabilitate")
    private Date dataIncepereValabilitate;

    @Column (name = "data_terminare_valabilitate")
    private Date dataTerminareValabilitate;

    @Column (name = "pret")
    private Integer pret;

    public Integer getPret() {
        return pret;
    }

    public void setPret(Integer pret) {
        this.pret = pret;
    }

    public Integer getAbonamentId() {
        return abonamentId;
    }

    public void setAbonamentId(Integer abonamentId) {
        this.abonamentId = abonamentId;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public String getPrenume() {
        return prenume;
    }

    public void setPrenume(String prenume) {
        this.prenume = prenume;
    }

    public Integer getTipLocId() {
        return tipLocId;
    }

    public void setTipLocId(Integer tipLocId) {
        this.tipLocId = tipLocId;
    }

    public Integer getTipCumparatorId() {
        return tipCumparatorId;
    }

    public void setTipCumparatorId(Integer tipCumparatorId) {
        this.tipCumparatorId = tipCumparatorId;
    }

    public Integer getTermenValabilitate() {
        return termenValabilitate;
    }

    public void setTermenValabilitate(Integer termenValabilitate) {
        this.termenValabilitate = termenValabilitate;
    }

    public Date getDataIncepereValabilitate() {
        return dataIncepereValabilitate;
    }

    public void setDataIncepereValabilitate(Date dataIncepereValabilitate) {
        this.dataIncepereValabilitate = dataIncepereValabilitate;
    }

    public Date getDataTerminareValabilitate() {
        return dataTerminareValabilitate;
    }

    public void setDataTerminareValabilitate(Date dataTerminareValabilitate) {
        this.dataTerminareValabilitate = dataTerminareValabilitate;
    }

    @Override
    public String toString() {
        return "Abonamente{" +
                "abonamentId=" + abonamentId +
                ", nume='" + nume + '\'' +
                ", prenume='" + prenume + '\'' +
                ", tipLocId=" + tipLocId +
                ", tipCumparatorId=" + tipCumparatorId +
                ", termenValabilitate=" + termenValabilitate +
                ", dataIncepereValabilitate=" + dataIncepereValabilitate +
                ", dataTerminareValabilitate=" + dataTerminareValabilitate +
                ", pret=" + pret +
                '}';
    }
}
