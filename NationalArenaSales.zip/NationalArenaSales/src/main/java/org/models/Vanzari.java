package org.models;


import javax.persistence.*;

@NamedQueries({
        @NamedQuery(
                name = "get_status",
                query = "from Vanzari where status like :status"
        )
})

@Entity
@Table(name = "vanzari")

public class Vanzari {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "sale_id")
    private Integer saleId;

    @Column(name = "tip_vanzare_id")
    private Integer tipVanzareId;

    @Column(name = "bilet_id")
    private Integer biletId;

    @Column(name = "meci_id")
    private Integer meciId;

    @Column(name = "status")
    private Integer status;

    @Column(name = "abonament_id")
    private Integer abonamentId;

    @Column(name = "pret")
    private Integer pret;

    public Integer getPret() {
        return pret;
    }

    public void setPret(Integer pret) {
        this.pret = pret;
    }

    public Integer getSaleId() {
        return saleId;
    }
    public void setSaleId(Integer saleId) {
        this.saleId = saleId;
    }
    public Integer getTipVanzareId() {
        return tipVanzareId;
    }
    public void setTipVanzareId(Integer tipVanzareId) {
        this.tipVanzareId = tipVanzareId;
    }
    public Integer getBiletId() {
        return biletId;
    }
    public void setBiletId(Integer biletId) {
        this.biletId = biletId;
    }
    public Integer getMeciId() {
        return meciId;
    }
    public void setMeciId(Integer meciId) {
        this.meciId = meciId;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getAbonamentId() {
        return abonamentId;
    }

    public void setAbonamentId(Integer abonamentId) {
        this.abonamentId = abonamentId;
    }

    @Override
    public String toString() {
        return "Vanzari{" +
                "saleId=" + saleId +
                ", tipVanzareId=" + tipVanzareId +
                ", biletId=" + biletId +
                ", meciId=" + meciId +
                ", status=" + status +
                ", abonamentId=" + abonamentId +
                ", pret=" + pret +
                '}';
    }
}
