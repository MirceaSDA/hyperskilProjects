package org.models;

import javax.persistence.*;

@NamedQueries({
        @NamedQuery(
                name = "get_price",
                query = "from Bilete where pret like :pret"
        )
})

@Entity
@Table(name = "bilete")

public class Bilete {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "bilet_id")
    private Integer biletId;

    @Column (name = "tip_loc_id")
    private Integer tipLocId;

    @Column (name = "tip_cumparator_id")
    private Integer tipCumparatorId;

    @Column (name = "pret")
    private Integer pret;

    @Column (name = "meci_id")
    private Integer mecId;

    @Column (name = "status")
    private Integer status;

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getMecId() {
        return mecId;
    }

    public void setMecId(Integer mecId) {
        this.mecId = mecId;
    }

    public Integer getBiletId() {
        return biletId;
    }

    public void setBiletId(Integer biletId) {
        this.biletId = biletId;
    }

    public Integer getTipLocId() {
        return tipLocId;
    }

    public void setTipLocId(Integer tipLocId) {
        this.tipLocId = tipLocId;
    }

    public Integer getTipCumparatorId() {
        return tipCumparatorId;
    }

    public void setTipCumparatorId(Integer tipCumparatorId) {
        this.tipCumparatorId = tipCumparatorId;
    }

    public Integer getPret() {
        return pret;
    }

    public void setPret(Integer pret) {
        this.pret = pret;
    }

    @Override
    public String toString() {
        return "Bilete{" +
                "biletId=" + biletId +
                ", tipLocId=" + tipLocId +
                ", tipCumparatorId=" + tipCumparatorId +
                ", pret=" + pret +
                ", mecId=" + mecId +
                ", status=" + status +
                '}';
    }
}
