package org.models;

import javax.persistence.*;

@NamedQueries({
        @NamedQuery(
                name = "get_tip_cumparator",
                query = "from TipCumparator where tip_cumparator_description like :tip_cumparator_description"
        )
})

@Entity
@Table(name = "tip_cumparator")

public class TipCumparator {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tip_cumparator_id")
    private Integer tipCumparatorId;

    @Column (name = "tip_cumparator_description")
    private String tipCumparatorDescription;

    public Integer getTipCumparatorId() {
        return tipCumparatorId;
    }

    public void setTipCumparatorId(Integer tipCumparatorId) {
        this.tipCumparatorId = tipCumparatorId;
    }

    public String getTipCumparatorDescription() {
        return tipCumparatorDescription;
    }

    public void setTipCumparatorDescription(String tipCumparatorDescription) {
        this.tipCumparatorDescription = tipCumparatorDescription;
    }

    @Override
    public String toString() {
        return "TipCumparator{" +
                "tipCumparatorId=" + tipCumparatorId +
                ", tipCumparatorDescription=" + tipCumparatorDescription +
                '}';
    }
}
