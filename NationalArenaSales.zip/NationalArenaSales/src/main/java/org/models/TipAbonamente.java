package org.models;

import javax.persistence.*;

@NamedQueries({
        @NamedQuery(
                name = "get_durata_abonament",
                query = "from TipAbonamente where durata_abonament like :durata_abonament"
        )
})

@Entity
@Table(name = "tip_abonamente")

public class TipAbonamente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tip_abonament_id")
    private Integer tipAbonamentId;

    @Column (name = "durata_abonament")
    private Integer durataAbonament;

    @Column (name = "descriere_durata")
    private String descriereDurata;

    public Integer getTipAbonamentId() {
        return tipAbonamentId;
    }

    public void setTipAbonamentId(Integer tipAbonamentId) {
        this.tipAbonamentId = tipAbonamentId;
    }

    public Integer getDurataAbonament() {
        return durataAbonament;
    }

    public void setDurataAbonament(Integer durataAbonament) {
        this.durataAbonament = durataAbonament;
    }

    public String getDescriereDurata() {
        return descriereDurata;
    }

    public void setDescriereDurata(String descriereDurata) {
        this.descriereDurata = descriereDurata;
    }

    @Override
    public String toString() {
        return "TipAbonamente{" +
                "tipAbonamentId=" + tipAbonamentId +
                ", durataAbonament=" + durataAbonament +
                ", descriereDurata='" + descriereDurata + '\'' +
                '}';
    }
}
