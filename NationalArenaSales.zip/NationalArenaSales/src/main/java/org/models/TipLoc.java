package org.models;

import javax.persistence.*;

@NamedQueries({
        @NamedQuery(
                name = "get_seat_by_name",
                query = "from TipLoc where seat_description like :seat_description"
        )
})

@Entity
@Table(name = "tip_loc")

public class TipLoc {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tip_loc_id")
    private Integer seatId;

    @Column (name = "seat_description")
    private String seatDescription;

    @Column (name = "nr_locuri")
    private Integer nrLocuri;

    @Column(name = "pret")
    private Integer pret;

    @Column(name = "pret_abonament")
    private Integer pretAbonament;

    public Integer getPretAbonament() {
        return pretAbonament;
    }

    public void setPretAbonament(Integer pretAbonament) {
        this.pretAbonament = pretAbonament;
    }

    public Integer getPret() {
        return pret;
    }

    public void setPret(Integer pret) {
        this.pret = pret;
    }

    public Integer getSeatId() {
        return seatId;
    }

    public void setSeatId(Integer seatId) {
        this.seatId = seatId;
    }

    public String getSeatDescription() {
        return seatDescription;
    }

    public void setSeatDescription(String seatDescription) {
        this.seatDescription = seatDescription;
    }

    public Integer getNrLocuri() {
        return nrLocuri;
    }

    public void setNrLocuri(Integer nrLocuri) {
        this.nrLocuri = nrLocuri;
    }

    @Override
    public String toString() {
        return "TipLoc{" +
                "seatId=" + seatId +
                ", seatDescription='" + seatDescription + '\'' +
                ", nrLocuri=" + nrLocuri +
                ", pret=" + pret +
                ", pretAbonament=" + pretAbonament +
                '}';
    }
}
