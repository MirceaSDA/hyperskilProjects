package org.services;

import org.config.HQLConfig;
import org.hibernate.Session;
import org.models.TipLoc;
import org.springframework.stereotype.Component;

@Component
public class TipLocService {

    public Integer getPretById(Integer tipLocId) {
        Session session = HQLConfig.getSessionFactory().openSession();
        TipLoc tipLoc = session.find(TipLoc.class, tipLocId);
        int pret = tipLoc.getPret();
        session.close();
        return pret;
    }

}
