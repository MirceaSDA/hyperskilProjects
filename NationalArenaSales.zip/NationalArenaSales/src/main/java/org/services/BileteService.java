package org.services;

import org.config.HQLConfig;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.models.Bilete;
import org.models.TipLoc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.Query;
import javax.xml.transform.Result;
import java.sql.*;
import java.util.InputMismatchException;
import java.util.*;

@Component
public class BileteService {
    private Scanner scanner = new Scanner(System.in);
    private Bilete bilete;//= new Bilete();

    @Autowired
    public BileteService (Bilete bilete) {
        this.bilete = bilete;
    }

    @Autowired
    public void setBilete(Bilete bilete) {
        this.bilete = bilete;
    }

    public Integer getBiletMaxId () {
        PreparedStatement prepstmt = null;
        String url = "jdbc:mysql://localhost:3306/nationalarenasales?serverTimezone=UTC";
        String user = "root";
        String pass = "77Claudiu18";
        String sqlQuery = "select max(bilet_id) as maxBiletId from bilete";
        Integer maxBiletId = null;
        try {
            Connection conn = DriverManager.getConnection(url, user, pass);
            prepstmt = conn.prepareStatement(sqlQuery);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        try {
            ResultSet rs = prepstmt.executeQuery();
            if(rs.next()) {
                maxBiletId = rs.getInt("maxBiletId");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return maxBiletId;
    }

    public void showBiletMaxId() {
        Session session = HQLConfig.getSessionFactory().openSession();
//        String getMaxBiletId = "SELECT * FROM bilete WHERE bilet_id IN (SELECT MAX(bilet_id) FROM bilete)";
        Query getMaxBiletIdQuery = session.createQuery("from org.models.Bilete where biletId in" +
                " (select max(biletId) from Bilete)");
        Bilete maxBiletId = (Bilete)getMaxBiletIdQuery.getSingleResult();
        System.out.println(maxBiletId);
        session.close();
    }

    public Integer getMeciIdByBiletId(Integer biletId) {
        Session session = HQLConfig.getSessionFactory().openSession();

        Query getMecIdByBiletId = session.createQuery("from org.models.Bilete where biletId = " + biletId);
        Bilete meciIdByBiletId = (Bilete)getMecIdByBiletId.getSingleResult();
        session.close();
        return meciIdByBiletId.getMecId();

//        Query getMecIdByBiletId = session.createQuery("select meciId from Bilete where biletId = " + biletId);
//        Integer meciIdByBiletId = getMecIdByBiletId.getFirstResult();
//        session.close();
//        return meciIdByBiletId;
    }

    public Integer numarBileteOk (Integer nrBileteScanner) {
        boolean numarBileteOk = false;
        int numarBilete = nrBileteScanner;
        while (!numarBileteOk) {
            try {
                if(numarBilete > 9) {
                    System.out.println("Puteti cumpara doar 9 bilete. Reincercati.");
                    System.out.println("Introduceti numarul de bilete:");
                    numarBilete = scanner.nextInt();
                    scanner.nextLine();
                } else if (numarBilete < 1) {
                    System.out.println("Nu puteti cumpara mai putin de 1 bilet. Reincercati.");
                    System.out.println("Introduceti numarul de bilete:");
                    numarBilete = scanner.nextInt();
                    scanner.nextLine();
                } else {
                    numarBileteOk = true;
                }
            } catch (InputMismatchException ex) {
                System.out.println("Va rugam introduceti doar numere");
                numarBileteOk = false;
            }
        }
        return numarBilete;
    }

}
