package org.services;

import org.models.Abonamente;

import java.sql.*;
import java.util.Scanner;

public class AbonamenteService {

    private Scanner scanner = new Scanner(System.in);
    private Abonamente bilet = new Abonamente();

    public Integer getAbonamentMaxId() {
        PreparedStatement prepstmt = null;
        String url = "jdbc:mysql://localhost:3306/nationalarenasales?serverTimezone=UTC";
        String user = "root";
        String pass = "77Claudiu18";
        String sqlQuery = "select max(abonament_id) as maxAbonamentId from abonamente";
        Integer maxAbonamentId = null;
        try {
            Connection conn = DriverManager.getConnection(url, user, pass);
            prepstmt = conn.prepareStatement(sqlQuery);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        try {
            ResultSet rs = prepstmt.executeQuery();
            if (rs.next()) {
                maxAbonamentId = rs.getInt("maxAbonamentId");
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return maxAbonamentId;
    }

    public Integer checkTermenValabilitateAbonament(int optiuneTermenValabilitateAbonament) {
            if (optiuneTermenValabilitateAbonament == 1 || optiuneTermenValabilitateAbonament == 6) {
                optiuneTermenValabilitateAbonament = 6;
            } else if (optiuneTermenValabilitateAbonament == 2 || optiuneTermenValabilitateAbonament == 12) {
                optiuneTermenValabilitateAbonament = 12;
            } else if (optiuneTermenValabilitateAbonament == 3 || optiuneTermenValabilitateAbonament == 24) {
                optiuneTermenValabilitateAbonament = 24;
            } else {
                System.out.println("Optiunea nu este corecta.");
                optiuneTermenValabilitateAbonament = -1;
            }
        return optiuneTermenValabilitateAbonament;
    }

//    public Integer getBiletMaxId () {
//        PreparedStatement prepstmt = null;
//        String url = "jdbc:mysql://localhost:3306/nationalarenasales?serverTimezone=UTC";
//        String user = "root";
//        String pass = "77Claudiu18";
//        String sqlQuery = "select max(bilet_id) as maxBiletId from bilete";
//        Integer maxBiletId = null;
//        try {
//            Connection conn = DriverManager.getConnection(url, user, pass);
//            prepstmt = conn.prepareStatement(sqlQuery);
//        } catch (SQLException ex) {
//            ex.printStackTrace();
//        }
//        try {
//            ResultSet rs = prepstmt.executeQuery();
//            if(rs.next()) {
//                maxBiletId = rs.getInt("maxBiletId");
//            }
//        } catch (SQLException throwables) {
//            throwables.printStackTrace();
//        }

    public Integer getPretAbonament(int tip_loc, int tip_cumparator, int termenValabilitate) {
        int pret;
        if (tip_loc == 1) {
            if (tip_cumparator == 1) {
                if (termenValabilitate == 6) {
                    pret = 300 / 2 * 50 / 100;
                } else if (termenValabilitate == 12) {
                    pret = 300 * 50 / 100;
                } else {
                    pret = 300 * 2 * 50 / 100;
                }
            } else if (tip_cumparator == 3) {
                if (termenValabilitate == 6) {
                    pret = 300 / 2 * 75 / 100;
                } else if (termenValabilitate == 12) {
                    pret = 300 * 75 / 100;
                } else {
                    pret = 300 * 2 * 75 / 100;
                }
            } else {
                if (termenValabilitate == 6) {
                    pret = 300 / 2;
                } else if (termenValabilitate == 12) {
                    pret = 300;
                } else {
                    pret = 300 * 2;
                }
            }
        } else if (tip_loc == 2) {
            if (tip_cumparator == 1) {
                if (termenValabilitate == 6) {
                    pret = 500 / 2 * 50 / 100;
                } else if (termenValabilitate == 12) {
                    pret = 500 * 50 / 100;
                } else {
                    pret = 500 * 2 * 50 / 100;
                }
            } else if (tip_cumparator == 3) {
                if (termenValabilitate == 6) {
                    pret = 500 / 2 * 75 / 100;
                } else if (termenValabilitate == 12) {
                    pret = 500 * 75 / 100;
                } else {
                    pret = 500 * 2 * 75 / 100;
                }
            } else {
                if (termenValabilitate == 6) {
                    pret = 500 / 2;
                } else if (termenValabilitate == 12) {
                    pret = 500;
                } else {
                    pret = 500 * 2;
                }
            }
        } else if (tip_loc == 3) {
            if (tip_cumparator == 1) {
                if (termenValabilitate == 6) {
                    pret = 400 / 2 * 50 / 100;
                } else if (termenValabilitate == 12) {
                    pret = 400 * 50 / 100;
                } else {
                    pret = 400 * 2 * 50 / 100;
                }
            } else if (tip_cumparator == 3) {
                if (termenValabilitate == 6) {
                    pret = 400 / 2 * 75 / 100;
                } else if (termenValabilitate == 12) {
                    pret = 400 * 75 / 100;
                } else {
                    pret = 400 * 2 * 75 / 100;
                }
            } else {
                if (termenValabilitate == 6) {
                    pret = 400 / 2;
                } else if (termenValabilitate == 12) {
                    pret = 400;
                } else {
                    pret = 400 * 2;
                }
            }
        } else {
            if (tip_cumparator == 1) {
                if (termenValabilitate == 6) {
                    pret = 1000 / 2 * 50 / 100;
                } else if (termenValabilitate == 12) {
                    pret = 1000 * 50 / 100;
                } else {
                    pret = 1000 * 2 * 50 / 100;
                }
            } else if (tip_cumparator == 3) {
                if (termenValabilitate == 6) {
                    pret = 1000 / 2 * 75 / 100;
                } else if (termenValabilitate == 12) {
                    pret = 1000 * 75 / 100;
                } else {
                    pret = 1000 * 2 * 75 / 100;
                }
            } else {
                if (termenValabilitate == 6) {
                    pret = 1000 / 2;
                } else if (termenValabilitate == 12) {
                    pret = 1000;
                } else {
                    pret = 1000 * 2;
                }
            }
        }
        return pret;
    }
}
