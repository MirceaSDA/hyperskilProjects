package org.utils;

import dao.AbonamenteDao;
import dao.BileteDao;
import dao.MeciuriDao;
import dao.VanzariDao;
import org.config.HQLConfig;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.models.Bilete;
import org.models.Meciuri;
import org.models.Vanzari;
import org.services.AbonamenteService;
import org.services.BileteService;
import org.services.TipLocService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.sql.Statement;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Component
public class MeniuAN {

    private Scanner scanner = new Scanner(System.in);
    @Autowired
    private TipLocService tipLocService; //= new TipLocService();
    private BileteDao biletDao = new BileteDao();
    private VanzariDao vanzareDao = new VanzariDao();
    private MeciuriDao meciDao = new MeciuriDao();
    @Autowired
    private BileteService biletService;// = new BileteService();  //instanta singleton ar fi bine sa se numeasca precum clasa

    private AbonamenteDao abonamentDao = new AbonamenteDao();
    private AbonamenteService abonamentService = new AbonamenteService();

    int option = -1;
    int optiuneBilet = -1;
    int pret;

    public void startProgram() {
        while (option != 9) {
            displayMeniuPrincipal();
            option = scanner.nextInt();
            scanner.nextLine();
            switch (option) {
                case 1:
                    displayMeniuBilet();
                    optiuneBilet = scanner.nextInt();
                    scanner.nextLine();
                    while (optiuneBilet != 3) {
                        switch (optiuneBilet) {
                            case 1:
                                meciDao.veziMeciuri();
                                displayMeniuBilet();
                                optiuneBilet = scanner.nextInt();
                                scanner.nextLine();
                                break;
                            case 2:
                                int meciId = 0;
                                try {
                                    Session session = HQLConfig.getSessionFactory().openSession();
                                    System.out.println("Introduceti id-ul meciului la care doriti sa asistati: ");
                                    meciId = scanner.nextInt();
                                    scanner.nextLine();
                                    session.close();
                                } catch (Exception ex) {
                                    System.out.println(ex.getMessage());
                                }
                                System.out.println("Introduceti zona din stadion:\n" +
                                        "1. Peluza\n" +
                                        "2. Tribuna 1\n" +
                                        "3. Tribuna 2\n" +
                                        "4. VIP");
                                int optiuneZona = scanner.nextInt();
                                scanner.nextLine();
                                System.out.println("Introduceti tip cumparator:\n" +
                                        "1. Copil (12 - 18 ani inclusiv)\n" +
                                        "2. Adult\n" +
                                        "3. Senior (peste 60 de ani)");
                                int tipCumparator = scanner.nextInt();
                                scanner.nextLine();
                                if (tipCumparator == 1) {
                                    pret = tipLocService.getPretById(optiuneZona) * 50 / 100;
                                } else if (tipCumparator == 3) {
                                    pret = tipLocService.getPretById(optiuneZona) * 75 / 100;
                                } else {
                                    pret = tipLocService.getPretById(optiuneZona);
                                }
                                System.out.println("Introduceti numarul de bilete:");
                                int numarBilete = 1;
                                boolean nrBileteOk = false;
                                while (!nrBileteOk) {
                                    try {
                                        numarBilete = biletService.numarBileteOk(scanner.nextInt());
                                        scanner.nextLine();
                                        nrBileteOk = true;
                                    } catch (InputMismatchException ex) {
                                        System.out.println("Nu ati introdus corect numarul de bilete. Reincercati.");
                                        System.out.println("Introduceti numarul de bilete:");
                                        scanner.nextLine();
                                    }
                                }
//                                while(!biletService.numarBileteOk(numarBilete)) {
//                                    System.out.println("Introduceti numarul de bilete:");
//                                    try {
//                                        numarBilete = scanner.nextInt();
//                                        biletService.numarBileteOk(numarBilete);
//                                    } catch (InputMismatchException ex) {
//                                        System.out.println("Va rugam introduceti doar numere");
//                                    }
//                                }
                                for (int i = 0; i < numarBilete; i++) {
                                    biletDao.cumparareBilet(optiuneZona, tipCumparator, pret, meciId);
                                    biletService.showBiletMaxId();
                                    Integer maxBiletId = biletService.getBiletMaxId();
                                    Integer meciIdByBiletId = biletService.getMeciIdByBiletId(maxBiletId);
                                    vanzareDao.vanzareBilet(maxBiletId, meciIdByBiletId, pret);
                                }
                                //vinzareDao.cumparareBilet();
                                optiuneBilet = 1;
                                break;
                            case 9:
                                option = 9;
                                break;
                        }
                    }
                    break;
                case 2:
                    System.out.println("Introduceti numele dumneavoastra:");
                    String nume = scanner.nextLine();
                    System.out.println("Introduceti prenumele dumneavoastra:");
                    String prenume = scanner.nextLine();
                    System.out.println("Introduceti zona din stadion:\n" +
                            "1. Peluza\n" +
                            "2. Tribuna 1\n" +
                            "3. Tribuna 2\n" +
                            "4. VIP");
                    int tipLocId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.println("Introduceti tip cumparator:\n" +
                            "1. Copil (12 - 18 ani inclusiv)\n" +
                            "2. Adult\n" +
                            "3. Senior (peste 60 de ani)");
                    int tipCumparatorId = scanner.nextInt();
                    scanner.nextLine();
                    if (tipCumparatorId == 1) {
                        pret = tipLocService.getPretById(tipLocId) * 50 / 100;
                    } else if (tipCumparatorId == 3) {
                        pret = tipLocService.getPretById(tipLocId) * 75 / 100;
                    } else {
                        pret = tipLocService.getPretById(tipLocId);
                    }
                    System.out.println("Introduceti perioada de valabilitate a abonamentului:\n" +
                            "1. 6 luni\n" +
                            "2. 12 luni\n" +
                            "3. 24 de luni");
                    int termenValabilitate = -1;
                    while (termenValabilitate == -1) {
                        try {
                            termenValabilitate = abonamentService.checkTermenValabilitateAbonament(scanner.nextInt());
                        } catch (InputMismatchException ex) {
                            System.out.println("Optiunea nu este corecta" + ex.getMessage());
                        } finally {
                            scanner.nextLine();
                        }
                    }
                    System.out.println("Introduceti data de incepere a valabilitatii abonamentului (yyyy-MM-dd):");
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    Date dataIncepereValabilitate = null;
                    try {
                        dataIncepereValabilitate = dateFormat.parse(scanner.nextLine());
                    } catch (ParseException e) {
                        System.out.println("Data introdusa nu este in formatul sugerat. " + e.getMessage());
                    }

                    Calendar c = Calendar.getInstance();
                    assert dataIncepereValabilitate != null;
                    c.setTime(dataIncepereValabilitate);
                    c.add(Calendar.MONTH, termenValabilitate);
                    Date dataTerminareValabilitate = c.getTime();
                    int pret = abonamentService.getPretAbonament(tipLocId, tipCumparatorId, termenValabilitate);
                    abonamentDao.cumparareAbonament(nume, prenume, tipLocId, tipCumparatorId, termenValabilitate, dataIncepereValabilitate,
                            dataTerminareValabilitate, pret);
                    int maxAbonamentId = abonamentService.getAbonamentMaxId();
                    vanzareDao.vanzareAbonament(maxAbonamentId, pret);

//                    Date currentDatePlusOneDay = Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
//                    localDateTime = localDateTime.plusHours(1).plusMinutes(2).minusMinutes(1).plusSeconds(1);
                    break;
                case 3:
                    System.out.println("Introduceti id-ul biletului pe care doriti sa il anulati:");
                    int idAnulareBilet = scanner.nextInt();
                    biletDao.anulareBilet(idAnulareBilet);
                    System.out.println("Biletul dvs. cu id " + idAnulareBilet + " a fost anulat.");
                    System.out.println();
                    break;
            }
        }
    }
    private void displayMeniuPrincipal() {
        System.out.println("SELECTEAZA O OPTIUNE\n" +
                "1. Cumpara bilet\n" +
                "2. Cumpara abonament\n" +
                "3. Anulare bilet\n" +
                "9. EXIT PROGRAM");
    }
    private void displayMeniuBilet() {
        System.out.println("SELECTEAZA O OPTIUNE\n" +
                "1. Afisare meciuri\n" +
                "2. Cumpara bilet\n" +
                "3. Revino la meniul principal\n" +
                "9. EXIT PROGRAM");
    }

//    private void displayMeniuAbonament() {
//        System.out.println("SELECTEAZA O OPTIUNE\n" +
//                "1. Afisare meciuri\n" +
//                "2. Cumpara abonament\n" +
//                "3. Revino la meniul principal\n" +
//                "9. EXIT PROGRAM");
//    }
}